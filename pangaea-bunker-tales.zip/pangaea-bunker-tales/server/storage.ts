import { users, gameSaves, type User, type InsertUser, type GameSave, type InsertGameSave } from "@shared/schema";
import { db } from "./db";
import { eq } from "drizzle-orm";

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  createGameSave(gameSave: InsertGameSave): Promise<GameSave>;
  updateGameSave(id: number, gameSave: Partial<InsertGameSave>): Promise<GameSave>;
  getGameSavesByUser(userId: number): Promise<GameSave[]>;
  getGameSave(id: number): Promise<GameSave | undefined>;
  deleteGameSave(id: number): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }

  async createGameSave(insertGameSave: InsertGameSave): Promise<GameSave> {
    const [gameSave] = await db
      .insert(gameSaves)
      .values(insertGameSave)
      .returning();
    return gameSave;
  }

  async updateGameSave(id: number, updateData: Partial<InsertGameSave>): Promise<GameSave> {
    const [gameSave] = await db
      .update(gameSaves)
      .set({ ...updateData, updatedAt: new Date() })
      .where(eq(gameSaves.id, id))
      .returning();
    return gameSave;
  }

  async getGameSavesByUser(userId: number): Promise<GameSave[]> {
    return await db.select().from(gameSaves).where(eq(gameSaves.userId, userId));
  }

  async getGameSave(id: number): Promise<GameSave | undefined> {
    const [gameSave] = await db.select().from(gameSaves).where(eq(gameSaves.id, id));
    return gameSave || undefined;
  }

  async deleteGameSave(id: number): Promise<void> {
    await db.delete(gameSaves).where(eq(gameSaves.id, id));
  }
}

export const storage = new DatabaseStorage();
