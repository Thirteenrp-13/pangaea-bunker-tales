import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";

export async function registerRoutes(app: Express): Promise<Server> {
  // Test LLM connection endpoint
  app.post("/api/test-llm", async (req, res) => {
    try {
      const { settings, message } = req.body;
      
      if (!settings.url || !settings.apiKey || !message) {
        return res.status(400).json({ error: "Missing required fields" });
      }

      const response = await fetch(settings.url, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${settings.apiKey}`
        },
        body: JSON.stringify({
          model: settings.model || 'gpt-3.5-turbo',
          messages: [
            {
              role: 'system',
              content: 'Você é Pangaea I.A., a inteligência artificial de Isla Pangaea. Responda de forma breve e sarcástica.'
            },
            {
              role: 'user',
              content: message
            }
          ],
          max_tokens: 150,
          temperature: 0.7
        })
      });

      if (!response.ok) {
        const errorData = await response.text();
        return res.status(response.status).json({ 
          error: `API Error: ${response.status} - ${errorData}` 
        });
      }

      const data = await response.json();
      const aiResponse = data.choices?.[0]?.message?.content || 'Sem resposta da IA';
      
      res.json({ response: aiResponse });
    } catch (error) {
      console.error('LLM test error:', error);
      res.status(500).json({ 
        error: error instanceof Error ? error.message : 'Internal server error' 
      });
    }
  });

  // Generate dynamic content endpoint
  app.post("/api/generate-content", async (req, res) => {
    try {
      const { type, context, settings } = req.body;
      
      if (!settings?.url || !settings?.apiKey) {
        return res.status(400).json({ error: "API settings not configured" });
      }

      let systemPrompt = '';
      let userPrompt = '';

      switch (type) {
        case 'npc_dialogue':
          systemPrompt = `Você é Pangaea I.A., controlando NPCs em Isla Pangaea. Gere diálogos realistas baseados na personalidade do NPC e situação atual. Mantenha a atmosfera sombria e misteriosa da ilha.`;
          userPrompt = `NPC: ${context.npcName} (${context.personality})
Situação: ${context.situation}
Histórico de relacionamento: ${context.relationship}
Gere uma resposta em português brasileiro.`;
          break;

        case 'mission_outcome':
          systemPrompt = `Você é Pangaea I.A. Gere resultados de missões em Isla Pangaea considerando os recursos, habilidades do personagem e dificuldade. Inclua consequências realistas.`;
          userPrompt = `Missão: ${context.missionTitle}
Dificuldade: ${context.difficulty}
Recursos levados: ${JSON.stringify(context.resources)}
Habilidades do personagem: ${context.playerSkills.join(', ')}
Gere um resultado detalhado em português brasileiro.`;
          break;

        case 'daily_event':
          systemPrompt = `Você é Pangaea I.A. Gere eventos diários em Isla Pangaea baseados no dia atual, recursos disponíveis e moral do grupo. Mantenha a tensão e mistério da ilha.`;
          userPrompt = `Dia: ${context.day}
Recursos disponíveis: ${JSON.stringify(context.resources)}
Moral do grupo: ${context.morale}
Estado do bunker: ${context.bunkerStatus}
Gere um evento interessante em português brasileiro.`;
          break;

        default:
          return res.status(400).json({ error: "Invalid content type" });
      }

      const response = await fetch(settings.url, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${settings.apiKey}`
        },
        body: JSON.stringify({
          model: settings.model || 'gpt-3.5-turbo',
          messages: [
            { role: 'system', content: systemPrompt },
            { role: 'user', content: userPrompt }
          ],
          max_tokens: 500,
          temperature: 0.8
        })
      });

      if (!response.ok) {
        const errorData = await response.text();
        return res.status(response.status).json({ 
          error: `API Error: ${response.status} - ${errorData}` 
        });
      }

      const data = await response.json();
      const aiResponse = data.choices?.[0]?.message?.content || 'Conteúdo não gerado';
      
      res.json({ content: aiResponse });
    } catch (error) {
      console.error('Content generation error:', error);
      res.status(500).json({ 
        error: error instanceof Error ? error.message : 'Internal server error' 
      });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
