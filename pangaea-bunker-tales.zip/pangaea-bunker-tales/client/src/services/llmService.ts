interface APISettings {
  model: string;
  url: string;
  apiKey: string;
}

interface ContentContext {
  [key: string]: any;
}

export const getAPISettings = (): APISettings | null => {
  const saved = localStorage.getItem('pangaea_api_settings');
  return saved ? JSON.parse(saved) : null;
};

export const generateNPCDialogue = async (
  npcName: string,
  personality: string,
  situation: string,
  relationship: string
): Promise<string> => {
  const settings = getAPISettings();
  if (!settings) {
    return `[PANGAEA I.A. OFFLINE] ${npcName} olha para você em silêncio, mas o sistema de comunicação não está funcionando.`;
  }

  try {
    const response = await fetch('/api/generate-content', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        type: 'npc_dialogue',
        context: {
          npcName,
          personality,
          situation,
          relationship
        },
        settings
      })
    });

    const data = await response.json();
    return data.content || `${npcName}: *comunicação perdida*`;
  } catch (error) {
    return `[ERRO DE COMUNICAÇÃO] ${npcName} tenta falar, mas o sinal está interferindo.`;
  }
};

export const generateMissionOutcome = async (
  missionTitle: string,
  difficulty: string,
  resources: any,
  playerSkills: string[]
): Promise<string> => {
  const settings = getAPISettings();
  if (!settings) {
    return `PANGAEA I.A. não está disponível para calcular o resultado da missão. Resultados podem ser imprevisíveis.`;
  }

  try {
    const response = await fetch('/api/generate-content', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        type: 'mission_outcome',
        context: {
          missionTitle,
          difficulty,
          resources,
          playerSkills
        },
        settings
      })
    });

    const data = await response.json();
    return data.content || `Missão concluída com resultados indefinidos devido a falha no sistema.`;
  } catch (error) {
    return `ERRO: Não foi possível calcular o resultado da missão. Sistema de análise indisponível.`;
  }
};

export const generateDailyEvent = async (
  day: number,
  resources: any,
  relationships: any[]
): Promise<string> => {
  const settings = getAPISettings();
  if (!settings) {
    return `DIA ${day}: O bunker permanece em silêncio. Pangaea I.A. não está respondendo aos sistemas de monitoramento.`;
  }

  try {
    const response = await fetch('/api/generate-content', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        type: 'daily_event',
        context: {
          day,
          resources,
          relationships
        },
        settings
      })
    });

    const data = await response.json();
    return data.content || `DIA ${day}: Nada significativo acontece. Os sistemas parecem estar falhando.`;
  } catch (error) {
    return `DIA ${day}: ALERTA - Sistemas de monitoramento da ilha estão instáveis.`;
  }
};

export const isLLMConfigured = (): boolean => {
  const settings = getAPISettings();
  return !!(settings?.url && settings?.apiKey);
};