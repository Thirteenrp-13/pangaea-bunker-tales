import React, { useState } from 'react';
import { ArrowLeft, MapPin, Clock, AlertTriangle, Bot, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { generateMissionOutcome, isLLMConfigured } from '../../services/llmService';
import { PlayerCharacter } from '../../pages/Index';

interface MissionInterfaceProps {
  onBack: () => void;
  resources: {
    water: number;
    food: number;
    medicine: number;
    materials: number;
  };
  setResources: (resources: any) => void;
  playerCharacter?: PlayerCharacter;
}

interface Mission {
  id: string;
  title: string;
  description: string;
  region: string;
  difficulty: 'Baixa' | 'Média' | 'Alta';
  duration: string;
  rewards: string[];
  risks: string[];
}

export const MissionInterface: React.FC<MissionInterfaceProps> = ({ 
  onBack, 
  resources, 
  setResources,
  playerCharacter 
}) => {
  const [selectedMission, setSelectedMission] = useState<Mission | null>(null);
  const [missionResult, setMissionResult] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const availableMissions: Mission[] = [
    {
      id: '1',
      title: 'Explorar Praia Norte',
      description: 'Procurar por destroços do navio e suprimentos que possam ter sido arrastados pela maré.',
      region: 'Praia Norte',
      difficulty: 'Baixa',
      duration: '2 horas',
      rewards: ['Água: +2-4', 'Materiais: +1-3'],
      risks: ['Possível encontro com vida selvagem']
    },
    {
      id: '2',
      title: 'Investigar Floresta Densa',
      description: 'Buscar por fontes de água doce e plantas comestíveis, mas a vegetação é perigosa.',
      region: 'Floresta Central',
      difficulty: 'Alta',
      duration: '4 horas',
      rewards: ['Água: +5-8', 'Comida: +3-6', 'Medicina: +1-2'],
      risks: ['Animais perigosos', 'Plantas venenosas', 'Possibilidade de se perder']
    },
    {
      id: '3',
      title: 'Escalar Colina Rochosa',
      description: 'Subir até o ponto mais alto para ter uma visão geral da ilha e procurar sinais de civilização.',
      region: 'Colinas Rochosas',
      difficulty: 'Média',
      duration: '3 horas',
      rewards: ['Mapa da região', 'Possível sinal de rádio'],
      risks: ['Queda de rochas', 'Fadiga extrema']
    }
  ];

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'Baixa': return 'text-green-400';
      case 'Média': return 'text-yellow-400';
      case 'Alta': return 'text-red-400';
      default: return 'text-slate-400';
    }
  };

  const executeMission = async (mission: Mission) => {
    if (!playerCharacter) return;

    setIsLoading(true);
    try {
      const playerSkills = playerCharacter.traits || [];
      const outcome = await generateMissionOutcome(
        mission.title,
        mission.difficulty,
        resources,
        playerSkills
      );

      setMissionResult(outcome);

      // Simular mudanças básicas de recursos baseadas na dificuldade
      const difficultyMultiplier = mission.difficulty === 'Alta' ? 2 : mission.difficulty === 'Média' ? 1.5 : 1;
      const baseWaterGain = Math.floor((Math.random() * 3 + 2) * difficultyMultiplier);
      const baseFoodGain = Math.floor((Math.random() * 3 + 1) * difficultyMultiplier);
      const baseMaterialGain = Math.floor((Math.random() * 2 + 1) * difficultyMultiplier);
      
      setResources({
        ...resources,
        water: Math.min(100, resources.water + baseWaterGain),
        food: Math.min(100, resources.food + baseFoodGain),
        materials: Math.min(100, resources.materials + baseMaterialGain)
      });

      // Resultado fica visível até o usuário fechar

    } catch (error) {
      console.error('Erro ao executar missão:', error);
      setMissionResult('Algo deu errado durante a missão...');
    } finally {
      setIsLoading(false);
    }
  };

  const handleCloseMissionResult = () => {
    setMissionResult(null);
    onBack();
  };

  if (missionResult) {
    return (
      <div className="min-h-screen p-4 max-w-4xl mx-auto flex items-center justify-center">
        <Card className="bg-slate-800/95 border-cyan-500/30 w-full shadow-2xl shadow-cyan-500/10">
          <CardHeader className="text-center border-b border-cyan-500/20 pb-4">
            <div className="flex items-center justify-between">
              <div className="flex-1"></div>
              <CardTitle className="text-cyan-400 text-2xl font-mono flex items-center justify-center flex-1">
                <Bot className="mr-3 h-8 w-8 text-emerald-400" />
                RELATÓRIO DE MISSÃO
              </CardTitle>
              <div className="flex-1 flex justify-end">
                <Button
                  onClick={handleCloseMissionResult}
                  variant="ghost"
                  size="sm"
                  className="text-slate-400 hover:text-cyan-400 transition-colors"
                >
                  <X className="h-6 w-6" />
                </Button>
              </div>
            </div>
            <div className="text-slate-400 text-sm font-mono mt-2">
              PANGAEA I.A. • STATUS: ATIVO
            </div>
          </CardHeader>
          <CardContent className="p-8">
            <div className="bg-slate-900/50 border border-cyan-500/20 rounded-lg p-6 mb-6">
              <div 
                className="text-slate-100 text-base leading-relaxed font-mono whitespace-pre-wrap"
                style={{ fontSize: '16px', lineHeight: '1.6' }}
                dangerouslySetInnerHTML={{ 
                  __html: missionResult
                    .replace(/\*\*(.*?)\*\*/g, '<strong class="text-cyan-400">$1</strong>')
                    .replace(/\*(.*?)\*/g, '<em class="text-emerald-400">$1</em>')
                    .replace(/\n/g, '<br>')
                }}
              />
            </div>
            <div className="text-center">
              <Button
                onClick={handleCloseMissionResult}
                className="bg-cyan-600 hover:bg-cyan-700 text-white font-mono px-8"
              >
                Retornar ao Bunker
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen p-4 max-w-2xl mx-auto">
      <div className="flex items-center mb-6">
        <Button 
          onClick={onBack}
          variant="ghost" 
          className="text-slate-300 hover:text-white"
        >
          <ArrowLeft className="mr-2 h-4 w-4" />
          Voltar ao Bunker
        </Button>
      </div>

      <div className="mb-6">
        <h1 className="text-2xl font-bold text-green-400 font-mono mb-2 flex items-center">
          <Bot className="mr-2 h-6 w-6" />
          EXPLORAÇÃO DA ILHA
        </h1>
        <p className="text-slate-300 text-sm">
          Escolha cuidadosamente suas missões. A IA irá determinar os resultados baseado em suas habilidades.
        </p>
      </div>

      {!selectedMission ? (
        <div className="space-y-4">
          {availableMissions.map((mission) => (
            <Card 
              key={mission.id}
              className="bg-slate-800/70 border-slate-700 hover:bg-slate-800 transition-colors cursor-pointer"
              onClick={() => setSelectedMission(mission)}
            >
              <CardHeader className="pb-3">
                <div className="flex justify-between items-start">
                  <CardTitle className="text-white text-lg">
                    {mission.title}
                  </CardTitle>
                  <div className={`text-sm font-semibold ${getDifficultyColor(mission.difficulty)}`}>
                    {mission.difficulty}
                  </div>
                </div>
              </CardHeader>
              <CardContent className="pt-0">
                <p className="text-slate-300 text-sm mb-3">
                  {mission.description}
                </p>
                <div className="flex items-center justify-between text-xs text-slate-400">
                  <div className="flex items-center">
                    <MapPin className="h-3 w-3 mr-1" />
                    {mission.region}
                  </div>
                  <div className="flex items-center">
                    <Clock className="h-3 w-3 mr-1" />
                    {mission.duration}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <div className="space-y-6">
          <Card className="bg-slate-800/70 border-slate-700">
            <CardHeader>
              <CardTitle className="text-white text-xl">
                {selectedMission.title}
              </CardTitle>
              <div className="flex items-center space-x-4 text-sm text-slate-400">
                <div className="flex items-center">
                  <MapPin className="h-4 w-4 mr-1" />
                  {selectedMission.region}
                </div>
                <div className="flex items-center">
                  <Clock className="h-4 w-4 mr-1" />
                  {selectedMission.duration}
                </div>
                <div className={`font-semibold ${getDifficultyColor(selectedMission.difficulty)}`}>
                  {selectedMission.difficulty}
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-slate-300 mb-4">
                {selectedMission.description}
              </p>
              
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <h4 className="text-green-400 font-semibold mb-2 text-sm">
                    Recompensas Possíveis:
                  </h4>
                  <ul className="text-slate-300 text-sm space-y-1">
                    {selectedMission.rewards.map((reward, index) => (
                      <li key={index}>• {reward}</li>
                    ))}
                  </ul>
                </div>
                
                <div>
                  <h4 className="text-red-400 font-semibold mb-2 text-sm flex items-center">
                    <AlertTriangle className="h-4 w-4 mr-1" />
                    Riscos:
                  </h4>
                  <ul className="text-slate-300 text-sm space-y-1">
                    {selectedMission.risks.map((risk, index) => (
                      <li key={index}>• {risk}</li>
                    ))}
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>

          <div className="flex space-x-3">
            <Button
              onClick={() => setSelectedMission(null)}
              variant="outline"
              className="flex-1 border-slate-600 text-slate-300 hover:bg-slate-700"
              disabled={isLoading}
            >
              Cancelar
            </Button>
            <Button
              onClick={() => executeMission(selectedMission)}
              className="flex-1 bg-green-600 hover:bg-green-700 text-white font-semibold"
              disabled={isLoading}
            >
              {isLoading ? (
                <>
                  <Bot className="mr-2 h-4 w-4 animate-spin" />
                  IA Processando...
                </>
              ) : (
                'Iniciar Missão'
              )}
            </Button>
          </div>
        </div>
      )}
    </div>
  );
};
