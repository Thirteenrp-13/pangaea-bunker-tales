import React from 'react';
import { 
  Compass, 
  Users, 
  Package, 
  TrendingUp, 
  Calendar,
  Droplets,
  Utensils,
  Heart,
  Zap,
  Moon,
  AlertTriangle,
  Wifi,
  Battery,
  Satellite,
  Eye,
  Brain,
  Shield,
  WifiOff,
  Save
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { PlayerCharacter } from '../../pages/Index';
import { GameView } from './GameInterface';
import { isLLMConfigured } from '../../services/llmService';

interface BunkerInterfaceProps {
  playerCharacter: PlayerCharacter;
  gameDay: number;
  resources: {
    water: number;
    food: number;
    medicine: number;
    materials: number;
  };
  moraleStatus: 'high' | 'normal' | 'low' | 'critical';
  onNavigate: (view: GameView) => void;
  onAdvanceDay: () => void;
  onSaveGame?: () => void;
}

export const BunkerInterface: React.FC<BunkerInterfaceProps> = ({
  playerCharacter,
  gameDay,
  resources,
  moraleStatus,
  onNavigate,
  onAdvanceDay,
  onSaveGame
}) => {
  const getMoraleColor = (status: string) => {
    switch (status) {
      case 'high': return 'text-green-400';
      case 'normal': return 'text-blue-400';
      case 'low': return 'text-yellow-400';
      case 'critical': return 'text-red-400';
      default: return 'text-slate-400';
    }
  };

  const getResourceColor = (value: number) => {
    if (value >= 70) return 'bg-green-500';
    if (value >= 40) return 'bg-yellow-500';
    if (value >= 20) return 'bg-orange-500';
    return 'bg-red-500';
  };

  const getCurrentTime = () => {
    const now = new Date();
    return now.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-emerald-950 via-slate-900 to-cyan-950 p-4 relative overflow-hidden">
      {/* Background effects */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_rgba(6,78,59,0.4)_0%,_transparent_50%)]"></div>
      
      {/* Smartwatch Interface Container */}
      <div className="max-w-md mx-auto relative z-10">
        {/* Watch Header */}
        <div className="bg-slate-900/95 border-2 border-emerald-400/30 rounded-3xl p-1 mb-4 backdrop-blur-xl shadow-2xl shadow-emerald-900/50">
          <div className="bg-slate-800/50 rounded-2xl p-4">
            {/* Status Bar */}
            <div className="flex justify-between items-center mb-4 text-xs font-mono">
              <div className="flex items-center gap-2">
                <Wifi className="w-3 h-3 text-red-400" />
                <span className="text-red-400">SEM SINAL</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-emerald-400">{getCurrentTime()}</span>
                <Battery className="w-3 h-3 text-emerald-400" />
                <span className="text-emerald-400">87%</span>
              </div>
            </div>

            {/* Main Display */}
            <div className="text-center mb-4">
              <h1 className="text-lg font-bold text-emerald-100 font-mono mb-1">PAINEL BUNKER</h1>
              <div className="flex items-center justify-center gap-2 text-emerald-400/80 text-sm font-mono">
                {isLLMConfigured() ? (
                  <>
                    <Satellite className="w-4 h-4" />
                    <span>PANGAEA I.A. ATIVO</span>
                  </>
                ) : (
                  <>
                    <WifiOff className="w-4 h-4" />
                    <span className="text-red-400">I.A. NÃO CONFIGURADA</span>
                  </>
                )}
              </div>
            </div>

            {/* Character Info */}
            <div className="flex items-center gap-3 mb-4 p-3 bg-emerald-900/20 rounded-lg border border-emerald-400/20">
              <div className="w-12 h-12 rounded-full bg-emerald-900/50 border border-emerald-400/40 flex items-center justify-center overflow-hidden">
                {playerCharacter.avatar ? (
                  <img 
                    src={playerCharacter.avatar} 
                    alt={playerCharacter.name} 
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <Eye className="w-6 h-6 text-emerald-400" />
                )}
              </div>
              <div className="flex-1">
                <h3 className="text-emerald-100 font-mono text-sm font-bold">{playerCharacter.name}</h3>
                <div className="flex items-center gap-2 text-xs">
                  <Calendar className="w-3 h-3 text-emerald-400" />
                  <span className="text-emerald-400 font-mono">DIA {gameDay}</span>
                </div>
              </div>
            </div>

            {/* Health Status */}
            <div className="mb-4 p-3 bg-slate-800/50 rounded-lg border border-emerald-400/20">
              <h4 className="text-emerald-300 font-mono text-xs mb-2 flex items-center gap-1">
                <Heart className="w-3 h-3" />
                STATUS VITAL
              </h4>
              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <span className="text-emerald-100 font-mono text-xs">Saúde</span>
                  <div className="flex items-center gap-2">
                    <div className="w-16 h-1.5 bg-slate-700 rounded-full">
                      <div className={`h-full rounded-full ${getResourceColor(playerCharacter.stats.health)}`} 
                           style={{ width: `${playerCharacter.stats.health}%` }}></div>
                    </div>
                    <span className="text-emerald-100 font-mono text-xs w-8">{playerCharacter.stats.health}%</span>
                  </div>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-emerald-100 font-mono text-xs">Energia</span>
                  <div className="flex items-center gap-2">
                    <div className="w-16 h-1.5 bg-slate-700 rounded-full">
                      <div className={`h-full rounded-full ${getResourceColor(playerCharacter.stats.stamina)}`} 
                           style={{ width: `${playerCharacter.stats.stamina}%` }}></div>
                    </div>
                    <span className="text-emerald-100 font-mono text-xs w-8">{playerCharacter.stats.stamina}%</span>
                  </div>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-emerald-100 font-mono text-xs">Moral</span>
                  <div className="flex items-center gap-2">
                    <div className="w-16 h-1.5 bg-slate-700 rounded-full">
                      <div className={`h-full rounded-full ${getResourceColor(playerCharacter.stats.morale)}`} 
                           style={{ width: `${playerCharacter.stats.morale}%` }}></div>
                    </div>
                    <span className="text-emerald-100 font-mono text-xs w-8">{playerCharacter.stats.morale}%</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Resources */}
            <div className="mb-4 p-3 bg-slate-800/50 rounded-lg border border-emerald-400/20">
              <h4 className="text-emerald-300 font-mono text-xs mb-2 flex items-center gap-1">
                <Package className="w-3 h-3" />
                RECURSOS
              </h4>
              <div className="grid grid-cols-2 gap-2">
                <div className="flex items-center gap-2">
                  <Droplets className="w-3 h-3 text-blue-400" />
                  <div className="flex-1">
                    <div className="flex justify-between">
                      <span className="text-emerald-100 font-mono text-xs">Água</span>
                      <span className="text-emerald-100 font-mono text-xs">{resources.water}L</span>
                    </div>
                    <div className="w-full h-1 bg-slate-700 rounded-full">
                      <div className={`h-full rounded-full ${getResourceColor(resources.water)}`} 
                           style={{ width: `${Math.min(resources.water, 100)}%` }}></div>
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Utensils className="w-3 h-3 text-yellow-400" />
                  <div className="flex-1">
                    <div className="flex justify-between">
                      <span className="text-emerald-100 font-mono text-xs">Comida</span>
                      <span className="text-emerald-100 font-mono text-xs">{resources.food}</span>
                    </div>
                    <div className="w-full h-1 bg-slate-700 rounded-full">
                      <div className={`h-full rounded-full ${getResourceColor(resources.food)}`} 
                           style={{ width: `${Math.min(resources.food, 100)}%` }}></div>
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Heart className="w-3 h-3 text-red-400" />
                  <div className="flex-1">
                    <div className="flex justify-between">
                      <span className="text-emerald-100 font-mono text-xs">Medicina</span>
                      <span className="text-emerald-100 font-mono text-xs">{resources.medicine}</span>
                    </div>
                    <div className="w-full h-1 bg-slate-700 rounded-full">
                      <div className={`h-full rounded-full ${getResourceColor(resources.medicine)}`} 
                           style={{ width: `${Math.min(resources.medicine, 100)}%` }}></div>
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Shield className="w-3 h-3 text-gray-400" />
                  <div className="flex-1">
                    <div className="flex justify-between">
                      <span className="text-emerald-100 font-mono text-xs">Material</span>
                      <span className="text-emerald-100 font-mono text-xs">{resources.materials}</span>
                    </div>
                    <div className="w-full h-1 bg-slate-700 rounded-full">
                      <div className={`h-full rounded-full ${getResourceColor(resources.materials)}`} 
                           style={{ width: `${Math.min(resources.materials, 100)}%` }}></div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Navigation Grid */}
            <div className="grid grid-cols-3 gap-2 mb-4">
              <Button
                onClick={() => onNavigate('missions')}
                className="h-16 bg-emerald-800/30 hover:bg-emerald-700/40 border border-emerald-400/30 flex flex-col items-center gap-1 font-mono text-xs"
              >
                <Compass className="w-4 h-4" />
                EXPEDIÇÕES
              </Button>
              <Button
                onClick={() => onNavigate('relationships')}
                className="h-16 bg-emerald-800/30 hover:bg-emerald-700/40 border border-emerald-400/30 flex flex-col items-center gap-1 font-mono text-xs"
              >
                <Users className="w-4 h-4" />
                EQUIPE
              </Button>
              <Button
                onClick={() => onNavigate('inventory')}
                className="h-16 bg-emerald-800/30 hover:bg-emerald-700/40 border border-emerald-400/30 flex flex-col items-center gap-1 font-mono text-xs"
              >
                <Package className="w-4 h-4" />
                INVENTÁRIO
              </Button>
            </div>

            {/* Action Buttons */}
            <div className="space-y-2">
              <Button
                onClick={() => onNavigate('skills')}
                className="w-full bg-emerald-700/40 hover:bg-emerald-600/50 border border-emerald-400/30 font-mono text-sm"
              >
                <Brain className="w-4 h-4 mr-2" />
                HABILIDADES
              </Button>
              {onSaveGame && (
                <Button
                  onClick={onSaveGame}
                  className="w-full bg-cyan-700/40 hover:bg-cyan-600/50 border border-cyan-400/30 font-mono text-sm"
                >
                  <Save className="w-4 h-4 mr-2" />
                  SALVAR PROGRESSO
                </Button>
              )}
              <Button
                onClick={onAdvanceDay}
                className="w-full bg-gradient-to-r from-amber-600/80 to-orange-600/80 hover:from-amber-500/80 hover:to-orange-500/80 border border-amber-400/30 font-mono text-sm"
              >
                <Moon className="w-4 h-4 mr-2" />
                DESCANSAR - PRÓXIMO DIA
              </Button>
            </div>

            {/* Status Alert */}
            {moraleStatus === 'critical' && (
              <div className="mt-3 p-2 bg-red-900/30 border border-red-400/40 rounded-lg flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 text-red-400" />
                <span className="text-red-400 font-mono text-xs">ALERTA: MORAL CRÍTICO</span>
              </div>
            )}

            {/* AI Status */}
            <div className="mt-3 text-center">
              <div className="inline-flex items-center gap-2 px-3 py-1 bg-emerald-900/30 rounded-full border border-emerald-400/20">
                <div className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></div>
                <span className="text-emerald-400 font-mono text-xs">PANGAEA I.A.</span>
                <div className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};