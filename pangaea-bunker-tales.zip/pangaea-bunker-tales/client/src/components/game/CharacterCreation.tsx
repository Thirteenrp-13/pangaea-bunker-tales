import React, { useState, useRef } from 'react';
import { ArrowLeft, Upload, User, Camera, Dna, Brain, Heart, Shield } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { PlayerCharacter } from '../../pages/Index';

interface CharacterCreationProps {
  onCharacterCreated: (character: PlayerCharacter) => void;
  onBack: () => void;
}

export const CharacterCreation: React.FC<CharacterCreationProps> = ({ 
  onCharacterCreated, 
  onBack 
}) => {
  const [character, setCharacter] = useState<Partial<PlayerCharacter>>({
    name: '',
    backstory: '',
    avatar: '',
    traits: [],
    stats: {
      health: 100,
      stamina: 100,
      morale: 75
    }
  });

  const [selectedTraits, setSelectedTraits] = useState<string[]>([]);
  const [selectedSpecialization, setSelectedSpecialization] = useState<string>('');
  const fileInputRef = useRef<HTMLInputElement>(null);

  const specializations = [
    { id: 'medico', name: 'Dr. Médico', description: 'Especialista em medicina de campo e tratamento de ferimentos', icon: Heart },
    { id: 'explorador', name: 'Explorador', description: 'Expert em navegação e sobrevivência selvagem', icon: Dna },
    { id: 'tecnico', name: 'Técnico', description: 'Engenheiro capaz de reparar e construir equipamentos', icon: Shield },
    { id: 'diplomata', name: 'Diplomata', description: 'Hábil em negociação e relações interpessoais', icon: Brain }
  ];

  const personalityTraits = [
    'Empático', 'Determinado', 'Cauteloso', 'Impulsivo',
    'Líder Natural', 'Analítico', 'Corajoso', 'Paranóico',
    'Otimista', 'Pragmático', 'Intuitivo', 'Meticuloso'
  ];

  const handleTraitToggle = (trait: string) => {
    if (selectedTraits.includes(trait)) {
      setSelectedTraits(selectedTraits.filter(t => t !== trait));
    } else if (selectedTraits.length < 3) {
      setSelectedTraits([...selectedTraits, trait]);
    }
  };

  const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        const result = e.target?.result as string;
        setCharacter(prev => ({ ...prev, avatar: result }));
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = () => {
    if (character.name && character.backstory && selectedSpecialization) {
      const finalCharacter: PlayerCharacter = {
        name: character.name,
        backstory: character.backstory,
        avatar: character.avatar || '',
        traits: [...selectedTraits, selectedSpecialization],
        stats: character.stats!
      };
      onCharacterCreated(finalCharacter);
    }
  };

  const isFormValid = character.name && character.backstory && selectedSpecialization && selectedTraits.length >= 2;

  return (
    <div className="min-h-screen bg-gradient-to-br from-emerald-950 via-slate-900 to-cyan-950 p-4 relative overflow-hidden">
      {/* Background effects */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_rgba(6,78,59,0.4)_0%,_transparent_50%)]"></div>
      
      <div className="max-w-4xl mx-auto relative z-10">
        {/* Header */}
        <div className="flex items-center gap-4 mb-6">
          <Button
            onClick={onBack}
            variant="ghost"
            className="text-emerald-400 hover:text-emerald-300 hover:bg-emerald-900/30"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Voltar
          </Button>
          <div className="flex-1">
            <h1 className="text-2xl font-bold text-emerald-100 font-mono">ARQUIVO DE EXPEDICIONÁRIO</h1>
            <p className="text-emerald-400/80 font-mono text-sm">Configure seu perfil para a missão</p>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Left Column - Character Info */}
          <div className="space-y-6">
            {/* Avatar Upload */}
            <Card className="bg-slate-900/95 border-emerald-400/30 backdrop-blur-xl">
              <CardHeader>
                <CardTitle className="text-emerald-100 font-mono flex items-center gap-2">
                  <Camera className="w-5 h-5" />
                  FOTO DO PERFIL
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex flex-col items-center gap-4">
                  <div className="w-32 h-32 rounded-full bg-emerald-900/30 border-2 border-emerald-400/40 flex items-center justify-center overflow-hidden">
                    {character.avatar ? (
                      <img 
                        src={character.avatar} 
                        alt="Avatar" 
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <User className="w-16 h-16 text-emerald-400/60" />
                    )}
                  </div>
                  <input
                    type="file"
                    ref={fileInputRef}
                    onChange={handleImageUpload}
                    accept="image/*"
                    className="hidden"
                  />
                  <Button
                    onClick={() => fileInputRef.current?.click()}
                    variant="outline"
                    className="border-emerald-400/40 text-emerald-300 hover:bg-emerald-900/50 font-mono"
                  >
                    <Upload className="w-4 h-4 mr-2" />
                    Fazer Upload
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Basic Info */}
            <Card className="bg-slate-900/95 border-emerald-400/30 backdrop-blur-xl">
              <CardHeader>
                <CardTitle className="text-emerald-100 font-mono">DADOS PESSOAIS</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <label className="text-emerald-300 font-mono text-sm">Nome Completo</label>
                  <Input
                    value={character.name || ''}
                    onChange={(e) => setCharacter(prev => ({ ...prev, name: e.target.value }))}
                    className="bg-slate-800/50 border-emerald-400/30 text-emerald-100 font-mono"
                    placeholder="Ex: Dr. Elena Vasquez"
                  />
                </div>
                <div>
                  <label className="text-emerald-300 font-mono text-sm">História Pessoal</label>
                  <Textarea
                    value={character.backstory || ''}
                    onChange={(e) => setCharacter(prev => ({ ...prev, backstory: e.target.value }))}
                    className="bg-slate-800/50 border-emerald-400/30 text-emerald-100 font-mono min-h-[100px]"
                    placeholder="Descreva sua experiência, motivação e o que te trouxe até Isla Pangaea..."
                  />
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Right Column - Specialization & Traits */}
          <div className="space-y-6">
            {/* Specialization */}
            <Card className="bg-slate-900/95 border-emerald-400/30 backdrop-blur-xl">
              <CardHeader>
                <CardTitle className="text-emerald-100 font-mono">ESPECIALIZAÇÃO</CardTitle>
                <p className="text-emerald-400/80 font-mono text-sm">Escolha sua área de expertise</p>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-3">
                  {specializations.map((spec) => {
                    const Icon = spec.icon;
                    return (
                      <div
                        key={spec.id}
                        onClick={() => setSelectedSpecialization(spec.id)}
                        className={`p-4 rounded-lg border-2 cursor-pointer transition-all duration-300 ${
                          selectedSpecialization === spec.id
                            ? 'border-emerald-400 bg-emerald-900/30'
                            : 'border-emerald-400/30 bg-slate-800/30 hover:border-emerald-400/50'
                        }`}
                      >
                        <div className="flex flex-col items-center text-center gap-2">
                          <Icon className="w-8 h-8 text-emerald-400" />
                          <h3 className="font-mono text-sm text-emerald-100">{spec.name}</h3>
                          <p className="text-xs text-emerald-400/70 font-mono">{spec.description}</p>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>

            {/* Personality Traits */}
            <Card className="bg-slate-900/95 border-emerald-400/30 backdrop-blur-xl">
              <CardHeader>
                <CardTitle className="text-emerald-100 font-mono">TRAÇOS DE PERSONALIDADE</CardTitle>
                <p className="text-emerald-400/80 font-mono text-sm">Selecione 2-3 características ({selectedTraits.length}/3)</p>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-3 gap-2">
                  {personalityTraits.map((trait) => (
                    <Badge
                      key={trait}
                      variant={selectedTraits.includes(trait) ? "default" : "outline"}
                      className={`cursor-pointer transition-all duration-300 font-mono text-xs p-2 text-center justify-center ${
                        selectedTraits.includes(trait)
                          ? 'bg-emerald-600 text-white border-emerald-400'
                          : 'border-emerald-400/40 text-emerald-300 hover:border-emerald-400/60 hover:bg-emerald-900/30'
                      }`}
                      onClick={() => handleTraitToggle(trait)}
                    >
                      {trait}
                    </Badge>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Status Display */}
            <Card className="bg-slate-900/95 border-emerald-400/30 backdrop-blur-xl">
              <CardHeader>
                <CardTitle className="text-emerald-100 font-mono">STATUS INICIAL</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-emerald-300 font-mono text-sm">Saúde</span>
                  <div className="flex items-center gap-2">
                    <div className="w-20 h-2 bg-slate-700 rounded-full">
                      <div className="w-full h-full bg-green-500 rounded-full"></div>
                    </div>
                    <span className="text-emerald-100 font-mono text-sm">100%</span>
                  </div>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-emerald-300 font-mono text-sm">Energia</span>
                  <div className="flex items-center gap-2">
                    <div className="w-20 h-2 bg-slate-700 rounded-full">
                      <div className="w-full h-full bg-blue-500 rounded-full"></div>
                    </div>
                    <span className="text-emerald-100 font-mono text-sm">100%</span>
                  </div>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-emerald-300 font-mono text-sm">Moral</span>
                  <div className="flex items-center gap-2">
                    <div className="w-20 h-2 bg-slate-700 rounded-full">
                      <div className="w-3/4 h-full bg-yellow-500 rounded-full"></div>
                    </div>
                    <span className="text-emerald-100 font-mono text-sm">75%</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Submit Button */}
        <div className="mt-8 flex justify-center">
          <Button
            onClick={handleSubmit}
            disabled={!isFormValid}
            className="bg-gradient-to-r from-emerald-600 to-emerald-700 hover:from-emerald-500 hover:to-emerald-600 text-white font-mono font-medium border border-emerald-400/30 shadow-lg shadow-emerald-900/50 transition-all duration-300 hover:shadow-emerald-400/30 px-8 py-3 text-lg"
          >
            CONFIRMAR EXPEDICIONÁRIO
          </Button>
        </div>
      </div>
    </div>
  );
};