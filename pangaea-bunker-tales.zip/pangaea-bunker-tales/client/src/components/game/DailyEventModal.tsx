
import React from 'react';
import { Bot, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

interface DailyEventModalProps {
  isOpen: boolean;
  onClose: () => void;
  event: string;
  day: number;
}

export const DailyEventModal: React.FC<DailyEventModalProps> = ({
  isOpen,
  onClose,
  event,
  day
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/80 flex items-center justify-center p-4 z-50">
      <Card className="bg-slate-800/95 border-cyan-500/30 max-w-2xl w-full shadow-2xl shadow-cyan-500/10">
        <CardHeader className="flex flex-row items-center justify-between border-b border-cyan-500/20 pb-4">
          <CardTitle className="text-cyan-400 text-xl font-mono flex items-center">
            <Bot className="mr-3 h-7 w-7 text-emerald-400" />
            RELATÓRIO DIÁRIO - DIA {day}
          </CardTitle>
          <Button
            onClick={onClose}
            variant="ghost"
            size="sm"
            className="text-slate-400 hover:text-cyan-400 transition-colors"
          >
            <X className="h-5 w-5" />
          </Button>
        </CardHeader>
        <CardContent className="p-6">
          <div className="bg-slate-900/50 border border-cyan-500/20 rounded-lg p-6 mb-6">
            <div 
              className="text-slate-100 text-base leading-relaxed font-mono whitespace-pre-wrap"
              style={{ fontSize: '15px', lineHeight: '1.6' }}
              dangerouslySetInnerHTML={{ 
                __html: event
                  .replace(/\*\*(.*?)\*\*/g, '<strong class="text-cyan-400">$1</strong>')
                  .replace(/\*(.*?)\*/g, '<em class="text-emerald-400">$1</em>')
                  .replace(/\n/g, '<br>')
              }}
            />
          </div>
          <div className="text-center text-xs text-slate-400 font-mono mb-4 border-t border-slate-700 pt-4">
            <div className="inline-flex items-center">
              <div className="w-1 h-1 bg-emerald-400 rounded-full mr-2"></div>
              PANGAEA I.A. • ANÁLISE COMPORTAMENTAL ATIVA
            </div>
          </div>
          <Button
            onClick={onClose}
            className="w-full bg-cyan-600 hover:bg-cyan-700 text-white font-mono"
          >
            Continuar
          </Button>
        </CardContent>
      </Card>
    </div>
  );
};
