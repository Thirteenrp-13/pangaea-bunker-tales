import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Compass, Zap, Skull, Monitor, WifiOff, AlertTriangle } from 'lucide-react';
import { SettingsModal } from './SettingsModal';

interface MainMenuProps {
  onStartNewGame: () => void;
}

export const MainMenu: React.FC<MainMenuProps> = ({ onStartNewGame }) => {
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-emerald-950 via-slate-900 to-cyan-950 p-4 relative overflow-hidden">
      {/* Background atmospheric effects */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_rgba(6,78,59,0.4)_0%,_transparent_50%)]"></div>
      <div className="absolute top-0 left-0 w-full h-full opacity-20 animate-pulse"></div>
      
      {/* Storm effects */}
      <div className="absolute top-10 right-10 text-amber-400 animate-bounce">
        <WifiOff className="w-6 h-6" />
      </div>
      <div className="absolute bottom-10 left-10 text-red-400 animate-pulse">
        <AlertTriangle className="w-5 h-5" />
      </div>
      
      <Card className="w-full max-w-md bg-slate-900/95 border-emerald-400/30 backdrop-blur-xl shadow-2xl shadow-emerald-900/50 relative">
        {/* Holographic border effect */}
        <div className="absolute inset-0 rounded-lg bg-gradient-to-r from-emerald-400/20 via-cyan-400/20 to-emerald-400/20 blur-sm"></div>
        
        <CardHeader className="text-center relative z-10">
          <div className="flex items-center justify-center mb-4">
            <div className="relative">
              <Compass className="w-12 h-12 text-emerald-400 animate-pulse" />
              <div className="absolute inset-0 w-12 h-12 border-2 border-emerald-400/30 rounded-full animate-spin"></div>
            </div>
          </div>
          <CardTitle className="text-3xl font-bold text-emerald-100 mb-2 font-mono tracking-wider">
            ISLA PANGAEA
          </CardTitle>
          <CardDescription className="text-emerald-300/80 font-mono text-sm">
            Echoes of the Storm
          </CardDescription>
          <div className="flex items-center justify-center gap-2 mt-4 p-2 bg-emerald-900/30 rounded border border-emerald-400/20">
            <div className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></div>
            <span className="text-xs text-emerald-400 font-mono">PANGAEA I.A. ONLINE</span>
            <div className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></div>
          </div>
        </CardHeader>
        
        <CardContent className="space-y-4 relative z-10">
          <Button 
            onClick={onStartNewGame}
            className="w-full bg-gradient-to-r from-emerald-600 to-emerald-700 hover:from-emerald-500 hover:to-emerald-600 text-white font-mono font-medium border border-emerald-400/30 shadow-lg shadow-emerald-900/50 transition-all duration-300 hover:shadow-emerald-400/30 h-12"
          >
            <Zap className="w-4 h-4 mr-2" />
            NOVA EXPEDIÇÃO
          </Button>
          
          <Button 
            variant="outline" 
            className="w-full border-emerald-400/40 text-emerald-300 hover:bg-emerald-900/50 hover:border-emerald-400/60 font-mono transition-all duration-300 h-12"
            disabled
          >
            <Monitor className="w-4 h-4 mr-2" />
            CARREGAR MISSÃO
          </Button>
          
          <Button 
            onClick={() => setIsSettingsOpen(true)}
            variant="outline" 
            className="w-full border-emerald-400/40 text-emerald-300 hover:bg-emerald-900/50 hover:border-emerald-400/60 font-mono transition-all duration-300 h-12"
          >
            <Skull className="w-4 h-4 mr-2" />
            CONFIGURAÇÕES
          </Button>
          
          <div className="text-center pt-4 border-t border-emerald-400/20 space-y-2">
            <div className="flex justify-between text-xs text-emerald-400/60 font-mono">
              <span>STATUS:</span>
              <span className="text-amber-400">TEMPESTADE ATIVA</span>
            </div>
            <div className="flex justify-between text-xs text-emerald-400/60 font-mono">
              <span>COORDENADAS:</span>
              <span className="text-red-400">CLASSIFICADAS</span>
            </div>
            <div className="flex justify-between text-xs text-emerald-400/60 font-mono">
              <span>COMUNICAÇÃO:</span>
              <span className="text-red-400">PERDIDA</span>
            </div>
            <p className="text-xs text-emerald-400/40 font-mono italic mt-3">
              &quot;Bem-vindos de volta à ilha que o tempo esqueceu...&quot;
            </p>
          </div>
        </CardContent>
      </Card>
      
      <SettingsModal 
        isOpen={isSettingsOpen} 
        onClose={() => setIsSettingsOpen(false)} 
      />
    </div>
  );
};