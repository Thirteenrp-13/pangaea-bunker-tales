import React, { useState, useEffect } from 'react';
import { X, Settings, Brain, Key, Server, Save } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

interface APISettings {
  model: string;
  url: string;
  apiKey: string;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({ isOpen, onClose }) => {
  const [apiSettings, setApiSettings] = useState<APISettings>({
    model: '',
    url: '',
    apiKey: ''
  });
  const [testMessage, setTestMessage] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [testResult, setTestResult] = useState<string | null>(null);

  useEffect(() => {
    // Carregar configurações salvas
    const savedSettings = localStorage.getItem('pangaea_api_settings');
    if (savedSettings) {
      setApiSettings(JSON.parse(savedSettings));
    }
  }, []);

  const handleSave = () => {
    localStorage.setItem('pangaea_api_settings', JSON.stringify(apiSettings));
    onClose();
  };

  const handleTest = async () => {
    if (!apiSettings.url || !apiSettings.apiKey || !testMessage.trim()) {
      setTestResult('Por favor, preencha todos os campos antes de testar.');
      return;
    }

    setIsLoading(true);
    setTestResult(null);

    try {
      const response = await fetch('/api/test-llm', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          settings: apiSettings,
          message: testMessage
        })
      });

      const data = await response.json();
      
      if (response.ok) {
        setTestResult(`✅ Teste bem-sucedido! Resposta: ${data.response}`);
      } else {
        setTestResult(`❌ Erro: ${data.error}`);
      }
    } catch (error) {
      setTestResult(`❌ Erro de conexão: ${error instanceof Error ? error.message : 'Erro desconhecido'}`);
    } finally {
      setIsLoading(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <Card className="w-full max-w-2xl bg-slate-900/95 border-emerald-400/30 backdrop-blur-xl shadow-2xl shadow-emerald-900/50">
        <CardHeader className="flex flex-row items-center justify-between">
          <div className="flex items-center gap-2">
            <Settings className="w-6 h-6 text-emerald-400" />
            <CardTitle className="text-emerald-100 font-mono">CONFIGURAÇÕES DO SISTEMA</CardTitle>
          </div>
          <Button
            onClick={onClose}
            variant="ghost"
            className="text-emerald-400 hover:text-emerald-300 hover:bg-emerald-900/30"
          >
            <X className="w-4 h-4" />
          </Button>
        </CardHeader>

        <CardContent className="space-y-6">
          {/* Proxy API Settings */}
          <div className="space-y-4">
            <div className="flex items-center gap-2 mb-4">
              <Brain className="w-5 h-5 text-emerald-400" />
              <h3 className="text-emerald-100 font-mono font-bold">CONFIGURAÇÕES DA IA</h3>
            </div>
            
            <div className="grid grid-cols-1 gap-4">
              <div>
                <Label htmlFor="model" className="text-emerald-300 font-mono text-sm">
                  Modelo da IA
                </Label>
                <Input
                  id="model"
                  value={apiSettings.model}
                  onChange={(e) => setApiSettings(prev => ({ ...prev, model: e.target.value }))}
                  placeholder="Ex: gpt-4, claude-3-sonnet, deepseek-chat"
                  className="bg-slate-800/50 border-emerald-400/30 text-emerald-100 font-mono"
                />
                <p className="text-emerald-400/60 text-xs font-mono mt-1">
                  Nome do modelo que será usado pela Pangaea I.A.
                </p>
              </div>

              <div>
                <Label htmlFor="url" className="text-emerald-300 font-mono text-sm">
                  URL da API
                </Label>
                <Input
                  id="url"
                  value={apiSettings.url}
                  onChange={(e) => setApiSettings(prev => ({ ...prev, url: e.target.value }))}
                  placeholder="https://api.openai.com/v1/chat/completions"
                  className="bg-slate-800/50 border-emerald-400/30 text-emerald-100 font-mono"
                />
                <p className="text-emerald-400/60 text-xs font-mono mt-1">
                  Endpoint completo da API de chat completions
                </p>
              </div>

              <div>
                <Label htmlFor="apiKey" className="text-emerald-300 font-mono text-sm">
                  Chave da API
                </Label>
                <Input
                  id="apiKey"
                  type="password"
                  value={apiSettings.apiKey}
                  onChange={(e) => setApiSettings(prev => ({ ...prev, apiKey: e.target.value }))}
                  placeholder="sk-..."
                  className="bg-slate-800/50 border-emerald-400/30 text-emerald-100 font-mono"
                />
                <p className="text-emerald-400/60 text-xs font-mono mt-1">
                  Sua chave de API (armazenada localmente)
                </p>
              </div>
            </div>
          </div>

          {/* Test Section */}
          <div className="border-t border-emerald-400/20 pt-4">
            <div className="flex items-center gap-2 mb-4">
              <Server className="w-5 h-5 text-emerald-400" />
              <h3 className="text-emerald-100 font-mono font-bold">TESTE DE CONECTIVIDADE</h3>
            </div>

            <div className="space-y-4">
              <div>
                <Label htmlFor="testMessage" className="text-emerald-300 font-mono text-sm">
                  Mensagem de teste
                </Label>
                <Textarea
                  id="testMessage"
                  value={testMessage}
                  onChange={(e) => setTestMessage(e.target.value)}
                  placeholder="Olá, Pangaea I.A. Como você está?"
                  className="bg-slate-800/50 border-emerald-400/30 text-emerald-100 font-mono min-h-[80px]"
                />
              </div>

              <Button
                onClick={handleTest}
                disabled={isLoading || !apiSettings.url || !apiSettings.apiKey || !testMessage.trim()}
                className="w-full bg-emerald-700/40 hover:bg-emerald-600/50 border border-emerald-400/30 font-mono"
              >
                {isLoading ? (
                  <>
                    <div className="w-4 h-4 border-2 border-emerald-400 border-t-transparent rounded-full animate-spin mr-2" />
                    Testando...
                  </>
                ) : (
                  <>
                    <Key className="w-4 h-4 mr-2" />
                    Testar Conexão
                  </>
                )}
              </Button>

              {testResult && (
                <div className={`p-3 rounded-lg border font-mono text-sm ${
                  testResult.startsWith('✅') 
                    ? 'bg-green-900/30 border-green-400/40 text-green-400'
                    : 'bg-red-900/30 border-red-400/40 text-red-400'
                }`}>
                  {testResult}
                </div>
              )}
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex gap-3 pt-4 border-t border-emerald-400/20">
            <Button
              onClick={onClose}
              variant="outline"
              className="flex-1 border-emerald-400/40 text-emerald-300 hover:bg-emerald-900/50 font-mono"
            >
              Cancelar
            </Button>
            <Button
              onClick={handleSave}
              className="flex-1 bg-gradient-to-r from-emerald-600 to-emerald-700 hover:from-emerald-500 hover:to-emerald-600 text-white font-mono"
            >
              <Save className="w-4 h-4 mr-2" />
              Salvar
            </Button>
          </div>

          {/* Info */}
          <div className="bg-emerald-900/20 border border-emerald-400/20 rounded-lg p-3">
            <p className="text-emerald-400/80 font-mono text-xs">
              ℹ️ Suas configurações são armazenadas localmente no navegador. A Pangaea I.A. 
              usará essas configurações para gerar eventos dinâmicos, diálogos de NPCs e 
              resultados de missões baseados na lore de Isla Pangaea.
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};